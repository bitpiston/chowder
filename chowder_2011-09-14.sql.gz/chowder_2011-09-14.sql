# ************************************************************
# Sequel Pro SQL dump
# Version 3408
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.1.57)
# Database: chowder
# Generation Time: 2011-09-15 06:33:22 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table config
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config`;

CREATE TABLE `config` (
  `name` tinytext NOT NULL,
  `value` tinytext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table date_formats
# ------------------------------------------------------------

DROP TABLE IF EXISTS `date_formats`;

CREATE TABLE `date_formats` (
  `format` tinytext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table ipc
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ipc`;

CREATE TABLE `ipc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` tinytext NOT NULL,
  `function` tinytext NOT NULL,
  `args` text NOT NULL,
  `daemon` char(32) NOT NULL,
  `site` tinytext NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table ipc_bak
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ipc_bak`;

CREATE TABLE `ipc_bak` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` tinytext NOT NULL,
  `function` tinytext NOT NULL,
  `args` text NOT NULL,
  `daemon` char(32) NOT NULL,
  `site` tinytext NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table ipc_periodic
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ipc_periodic`;

CREATE TABLE `ipc_periodic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` tinytext NOT NULL,
  `function` tinytext NOT NULL,
  `args` text NOT NULL,
  `daemon` char(32) NOT NULL,
  `site` tinytext NOT NULL,
  `interval` int(11) NOT NULL,
  `last_exec_time` int(11) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table modules
# ------------------------------------------------------------

DROP TABLE IF EXISTS `modules`;

CREATE TABLE `modules` (
  `id` tinytext NOT NULL,
  `revision` smallint(6) NOT NULL DEFAULT '0',
  `site_site` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_config
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_config`;

CREATE TABLE `site_config` (
  `name` tinytext NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_email_templates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_email_templates`;

CREATE TABLE `site_email_templates` (
  `name` tinytext NOT NULL,
  `subject` tinytext NOT NULL,
  `body` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_forums
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_forums`;

CREATE TABLE `site_forums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `parent_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `priority` int(11) NOT NULL,
  `threads` int(11) NOT NULL,
  `posts` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_forums_activity
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_forums_activity`;

CREATE TABLE `site_forums_activity` (
  `date` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `id` int(11) DEFAULT NULL,
  `title` text,
  `user_name` varchar(65) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_forums_config
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_forums_config`;

CREATE TABLE `site_forums_config` (
  `name` tinytext NOT NULL,
  `value` tinytext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_forums_notify
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_forums_notify`;

CREATE TABLE `site_forums_notify` (
  `user_id` int(11) NOT NULL,
  `thread_id` int(11) NOT NULL,
  `last_ntime` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_forums_posts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_forums_posts`;

CREATE TABLE `site_forums_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `thread_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `author_name` varchar(32) NOT NULL,
  `body` longtext NOT NULL,
  `date` int(11) NOT NULL,
  `edit_user` varchar(32) DEFAULT NULL,
  `edit_reason` text,
  `edit_date` int(11) DEFAULT NULL,
  `edit_count` int(11) DEFAULT '0',
  `replyto` int(11) DEFAULT NULL,
  `disable_signature` tinyint(4) NOT NULL,
  `disable_smiles` tinyint(4) NOT NULL,
  `disable_bbcode` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_forums_threads
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_forums_threads`;

CREATE TABLE `site_forums_threads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `forum_id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  `author_name` varchar(32) NOT NULL,
  `date` int(11) NOT NULL,
  `lastpost_date` int(11) DEFAULT NULL,
  `lastpost_id` int(11) DEFAULT NULL,
  `lastpost_author` varchar(32) DEFAULT NULL,
  `views` int(11) NOT NULL,
  `replies` int(11) NOT NULL,
  `sticky` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `moved_from` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_logs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_logs`;

CREATE TABLE `site_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinytext NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `message` text NOT NULL,
  `trace` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_styles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_styles`;

CREATE TABLE `site_styles` (
  `id` tinytext NOT NULL,
  `name` tinytext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `output` tinytext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_urls
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_urls`;

CREATE TABLE `site_urls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `url` tinytext NOT NULL,
  `url_hash` varchar(10) NOT NULL DEFAULT '',
  `title` tinytext CHARACTER SET utf8 NOT NULL,
  `module` tinytext NOT NULL,
  `function` tinytext NOT NULL,
  `params` tinytext NOT NULL,
  `show_nav_link` tinyint(1) NOT NULL DEFAULT '0',
  `nav_priority` smallint(6) NOT NULL DEFAULT '0',
  `regex` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`),
  KEY `url_hash` (`url_hash`),
  KEY `parent_id` (`parent_id`),
  KEY `regex` (`regex`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_user_config
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_user_config`;

CREATE TABLE `site_user_config` (
  `name` tinytext NOT NULL,
  `value` tinytext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_user_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_user_groups`;

CREATE TABLE `site_user_groups` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `name` tinytext CHARACTER SET utf8 NOT NULL,
  `user_admin_config` tinyint(1) NOT NULL DEFAULT '0',
  `user_admin_groups` tinyint(1) NOT NULL DEFAULT '0',
  `user_admin_manage` tinyint(1) NOT NULL DEFAULT '0',
  `admin_config` tinyint(1) NOT NULL DEFAULT '0',
  `admin_modules` tinyint(1) NOT NULL DEFAULT '0',
  `admin_styles` tinyint(1) NOT NULL DEFAULT '0',
  `admin_logs` tinyint(1) NOT NULL DEFAULT '0',
  `qdcontent_admin` tinyint(1) NOT NULL DEFAULT '0',
  `forums_admin` int(11) NOT NULL,
  `forums_admin_config` tinyint(1) NOT NULL DEFAULT '0',
  `forums_view` tinyint(1) NOT NULL DEFAULT '0',
  `forums_create_forums` tinyint(1) NOT NULL DEFAULT '0',
  `forums_edit_forums` tinyint(1) NOT NULL DEFAULT '0',
  `forums_delete_forums` tinyint(1) NOT NULL DEFAULT '0',
  `forums_create_threads` tinyint(1) NOT NULL DEFAULT '0',
  `forums_delete_threads` tinyint(1) NOT NULL DEFAULT '0',
  `forums_create_posts` tinyint(1) NOT NULL DEFAULT '0',
  `forums_edit_posts` tinyint(1) NOT NULL DEFAULT '0',
  `forums_delete_posts` tinyint(1) NOT NULL DEFAULT '0',
  `forums_move` tinyint(1) NOT NULL DEFAULT '0',
  `forums_merge` tinyint(1) NOT NULL DEFAULT '0',
  `forums_split` tinyint(1) NOT NULL DEFAULT '0',
  `forums_announce` tinyint(1) NOT NULL DEFAULT '0',
  `forums_sticky` tinyint(1) NOT NULL DEFAULT '0',
  `forums_lock` tinyint(1) NOT NULL DEFAULT '0',
  `forums_edit_threads` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_user_permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_user_permissions`;

CREATE TABLE `site_user_permissions` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `group_id` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table site_user_sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `site_user_sessions`;

CREATE TABLE `site_user_sessions` (
  `session_id` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip` tinytext NOT NULL,
  `access_ctime` int(11) NOT NULL,
  `restrict_ip` tinyint(1) NOT NULL,
  UNIQUE KEY `session_id` (`session_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sites`;

CREATE TABLE `sites` (
  `id` tinytext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table user_config
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_config`;

CREATE TABLE `user_config` (
  `name` tinytext NOT NULL,
  `value` tinytext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table user_email_changes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_email_changes`;

CREATE TABLE `user_email_changes` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `new_email` tinytext NOT NULL,
  `confirmation_hash` varchar(32) NOT NULL DEFAULT '',
  `ctime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table user_new
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_new`;

CREATE TABLE `user_new` (
  `name` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `email` tinytext NOT NULL,
  `ip` tinytext NOT NULL,
  `confirmation_hash` varchar(32) NOT NULL DEFAULT '',
  `ctime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table user_recover
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_recover`;

CREATE TABLE `user_recover` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `new_pass` char(64) NOT NULL DEFAULT '',
  `confirmation_hash` char(32) NOT NULL DEFAULT '',
  `ctime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `confirmation_hash` (`confirmation_hash`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `name_hash` varchar(10) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `email` tinytext NOT NULL,
  `session` varchar(32) NOT NULL DEFAULT '',
  `ip` tinytext NOT NULL,
  `time_offset` tinyint(4) NOT NULL DEFAULT '0',
  `date_format` tinytext NOT NULL,
  `restrict_ip` tinyint(1) NOT NULL DEFAULT '0',
  `style` tinytext NOT NULL,
  UNIQUE KEY `user_id` (`id`),
  KEY `session` (`session`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
